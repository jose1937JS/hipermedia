#
# TABLE STRUCTURE FOR: archivos
#

DROP TABLE IF EXISTS `archivos`;

CREATE TABLE `archivos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `tamano` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `ext` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `ruta` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `seccion_id` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seccion_id` (`seccion_id`),
  CONSTRAINT `archivos_ibfk_1` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

#
# TABLE STRUCTURE FOR: asignacion_usuario
#

DROP TABLE IF EXISTS `asignacion_usuario`;

CREATE TABLE `asignacion_usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `asignacion_id` int(11) NOT NULL,
  `estado` varchar(255) COLLATE utf8_spanish2_ci DEFAULT 'asignada',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asignacion_id` (`asignacion_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `asignacion_usuario_ibfk_1` FOREIGN KEY (`asignacion_id`) REFERENCES `asignaciones` (`id`),
  CONSTRAINT `asignacion_usuario_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

#
# TABLE STRUCTURE FOR: asignaciones
#

DROP TABLE IF EXISTS `asignaciones`;

CREATE TABLE `asignaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `deleted` varchar(5) COLLATE utf8_spanish2_ci DEFAULT 'false',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

#
# TABLE STRUCTURE FOR: chat
#

DROP TABLE IF EXISTS `chat`;

CREATE TABLE `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mensaje` varchar(512) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `chat_ibfk_1` (`usuario_id`),
  KEY `chat_ibfk_2` (`seccion_id`),
  CONSTRAINT `chat_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `chat_ibfk_2` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

#
# TABLE STRUCTURE FOR: chat_counter
#

DROP TABLE IF EXISTS `chat_counter`;

CREATE TABLE `chat_counter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contador` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `chat_counter_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `chat_counter` (`id`, `contador`, `usuario_id`) VALUES (1, 0, 1);
INSERT INTO `chat_counter` (`id`, `contador`, `usuario_id`) VALUES (2, 0, 2);


#
# TABLE STRUCTURE FOR: contenido_inicial
#

DROP TABLE IF EXISTS `contenido_inicial`;

CREATE TABLE `contenido_inicial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `contenido` varchar(5000) COLLATE utf8_spanish2_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `rutaimg` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seccion_id` (`seccion_id`),
  CONSTRAINT `contenido_inicial_ibfk_1` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `contenido_inicial` (`id`, `titulo`, `contenido`, `image`, `rutaimg`, `seccion_id`, `created_at`) VALUES (1, '123213', '123123123', 'harina_pan.jpeg', '/var/www/html/hipermedia/application/uploads/images/harina_pan.jpeg', 1, '2020-06-28 00:40:01');


#
# TABLE STRUCTURE FOR: contenidos
#

DROP TABLE IF EXISTS `contenidos`;

CREATE TABLE `contenidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contenido` text COLLATE utf8_spanish2_ci NOT NULL,
  `tema_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tema_id` (`tema_id`),
  CONSTRAINT `contenidos_ibfk_1` FOREIGN KEY (`tema_id`) REFERENCES `temas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `contenidos` (`id`, `contenido`, `tema_id`, `created_at`, `updated_at`) VALUES (1, '<p><strong>asd</strong></p>', 3, '2020-07-03 21:31:06', NULL);


#
# TABLE STRUCTURE FOR: examenes
#

DROP TABLE IF EXISTS `examenes`;

CREATE TABLE `examenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `valor_total` varchar(3) COLLATE utf8_spanish2_ci NOT NULL,
  `fechaLimite` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  `fechaPretty` varchar(64) COLLATE utf8_spanish2_ci NOT NULL,
  `duracion` varchar(9) COLLATE utf8_spanish2_ci NOT NULL,
  `vistas` smallint(6) DEFAULT '0',
  `aprobados` smallint(6) DEFAULT '0',
  `reprobados` smallint(6) DEFAULT '0',
  `tema_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tema_id` (`tema_id`),
  CONSTRAINT `examenes_ibfk_1` FOREIGN KEY (`tema_id`) REFERENCES `temas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `examenes` (`id`, `valor_total`, `fechaLimite`, `fechaPretty`, `duracion`, `vistas`, `aprobados`, `reprobados`, `tema_id`, `created_at`) VALUES (1, '100', '2020-07-15', '15 Julio, 2020', '00:30:00', 0, 0, 0, 3, '2020-07-03 21:31:39');


#
# TABLE STRUCTURE FOR: examenes_tomados
#

DROP TABLE IF EXISTS `examenes_tomados`;

CREATE TABLE `examenes_tomados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `puntuacion` varchar(5) COLLATE utf8_spanish2_ci NOT NULL,
  `examen_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `examen_id` (`examen_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `examenes_tomados_ibfk_1` FOREIGN KEY (`examen_id`) REFERENCES `examenes` (`id`),
  CONSTRAINT `examenes_tomados_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

#
# TABLE STRUCTURE FOR: herramientas
#

DROP TABLE IF EXISTS `herramientas`;

CREATE TABLE `herramientas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `enlace` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `imagen` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seccion_id` (`seccion_id`),
  CONSTRAINT `herramientas_ibfk_1` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

#
# TABLE STRUCTURE FOR: password_resets
#

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `expire_date` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

#
# TABLE STRUCTURE FOR: personas
#

DROP TABLE IF EXISTS `personas`;

CREATE TABLE `personas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(9) COLLATE utf8_spanish2_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `apellido` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `telefono` varchar(13) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cedula` (`cedula`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `personas` (`id`, `cedula`, `nombre`, `apellido`, `telefono`, `created_at`, `updated_at`) VALUES (1, '25887282', 'Jose', 'Lope', '0424-222-2222', '2020-06-27 12:30:40', NULL);
INSERT INTO `personas` (`id`, `cedula`, `nombre`, `apellido`, `telefono`, `created_at`, `updated_at`) VALUES (2, '10669419', 'Iraida', 'Lope', '0424-222-2222', '2020-06-27 13:32:18', NULL);


#
# TABLE STRUCTURE FOR: pregunta_respuestas
#

DROP TABLE IF EXISTS `pregunta_respuestas`;

CREATE TABLE `pregunta_respuestas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `valor` int(3) NOT NULL,
  `pregunta` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `respuesta` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `examen_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `examen_id` (`examen_id`),
  CONSTRAINT `pregunta_respuestas_ibfk_2` FOREIGN KEY (`examen_id`) REFERENCES `examenes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `pregunta_respuestas` (`id`, `tipo`, `valor`, `pregunta`, `respuesta`, `examen_id`, `created_at`) VALUES (1, 'Verdadero o Falso', 100, 'como me llam?', 'verdadero', 1, '2020-07-03 21:31:39');


#
# TABLE STRUCTURE FOR: respuesta_asignacion
#

DROP TABLE IF EXISTS `respuesta_asignacion`;

CREATE TABLE `respuesta_asignacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nota` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `respuesta` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `ext` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `asignacion_usuario_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asignacion_usuario_id` (`asignacion_usuario_id`),
  CONSTRAINT `respuesta_asignacion_ibfk_1` FOREIGN KEY (`asignacion_usuario_id`) REFERENCES `asignacion_usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

#
# TABLE STRUCTURE FOR: respuestas_incorrectas
#

DROP TABLE IF EXISTS `respuestas_incorrectas`;

CREATE TABLE `respuestas_incorrectas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `respuesta` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `preg_resp_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tema_id` (`preg_resp_id`),
  CONSTRAINT `respuestas_incorrectas_ibfk_1` FOREIGN KEY (`preg_resp_id`) REFERENCES `pregunta_respuestas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

#
# TABLE STRUCTURE FOR: secciones
#

DROP TABLE IF EXISTS `secciones`;

CREATE TABLE `secciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seccion` int(2) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `secciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `secciones` (`id`, `seccion`, `usuario_id`, `created_at`) VALUES (1, 2, 1, '2020-06-27 12:30:40');
INSERT INTO `secciones` (`id`, `seccion`, `usuario_id`, `created_at`) VALUES (2, 2, 2, '2020-06-27 13:32:18');


#
# TABLE STRUCTURE FOR: simuladores
#

DROP TABLE IF EXISTS `simuladores`;

CREATE TABLE `simuladores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `enlace` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `seccion_id` (`seccion_id`),
  CONSTRAINT `simuladores_ibfk_1` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

#
# TABLE STRUCTURE FOR: temas
#

DROP TABLE IF EXISTS `temas`;

CREATE TABLE `temas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lapso` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `tema` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `seccion_id` int(11) NOT NULL,
  `deleted` varchar(5) COLLATE utf8_spanish2_ci DEFAULT 'false',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `seccion_id` (`seccion_id`),
  CONSTRAINT `temas_ibfk_1` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `temas` (`id`, `lapso`, `tema`, `seccion_id`, `deleted`, `created_at`) VALUES (1, 'Tema 1', 'probando', 1, 'true', '2020-06-27 12:31:21');
INSERT INTO `temas` (`id`, `lapso`, `tema`, `seccion_id`, `deleted`, `created_at`) VALUES (2, 'Tema 1', 'asdadad', 1, 'true', '2020-06-27 13:32:32');
INSERT INTO `temas` (`id`, `lapso`, `tema`, `seccion_id`, `deleted`, `created_at`) VALUES (3, 'Tema 2', 'probando', 1, 'false', '2020-07-03 21:31:06');


#
# TABLE STRUCTURE FOR: usuarios
#

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `correo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `clave` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `tipo` varchar(64) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'Docente',
  `avatar` varchar(255) COLLATE utf8_spanish2_ci DEFAULT 'user.jpg',
  `persona_id` int(11) NOT NULL,
  `deleted` varchar(5) COLLATE utf8_spanish2_ci DEFAULT 'false',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `correo` (`correo`),
  KEY `persona_id` (`persona_id`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`persona_id`) REFERENCES `personas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `usuarios` (`id`, `correo`, `clave`, `tipo`, `avatar`, `persona_id`, `deleted`, `created_at`, `updated_at`) VALUES (1, 'jose@jose', '$2y$10$9r8n3XMhOy95NKzh1qaIVud4M3SOY.MMomLVH2/Gmfb2JSDmsrlKm', 'Docente', 'user.jpg', 1, 'false', '2020-06-27 12:30:40', NULL);
INSERT INTO `usuarios` (`id`, `correo`, `clave`, `tipo`, `avatar`, `persona_id`, `deleted`, `created_at`, `updated_at`) VALUES (2, 'ira@lope', '$2y$10$wl2raZPcTwDcmYbbL0iRn.ivPezAfsbO.X7FGAvqmQwU0/jLH8BxW', 'Estudiante', 'user.jpg', 2, 'false', '2020-06-27 13:32:18', NULL);


#
# TABLE STRUCTURE FOR: visitas
#

DROP TABLE IF EXISTS `visitas`;

CREATE TABLE `visitas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `tipo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

INSERT INTO `visitas` (`id`, `usuario`, `tipo`, `created_at`) VALUES (1, 'jose@jose', 'Docente', '2020-06-27 12:30:49');
INSERT INTO `visitas` (`id`, `usuario`, `tipo`, `created_at`) VALUES (2, 'ira@lope', 'Estudiante', '2020-06-27 13:32:48');
INSERT INTO `visitas` (`id`, `usuario`, `tipo`, `created_at`) VALUES (3, 'jose@jose', 'Docente', '2020-06-27 13:33:06');
INSERT INTO `visitas` (`id`, `usuario`, `tipo`, `created_at`) VALUES (4, 'jose@jose', 'Docente', '2020-06-28 00:37:05');
INSERT INTO `visitas` (`id`, `usuario`, `tipo`, `created_at`) VALUES (5, 'jose@jose', 'Docente', '2020-07-03 21:29:36');
INSERT INTO `visitas` (`id`, `usuario`, `tipo`, `created_at`) VALUES (6, 'jose@jose', 'Docente', '2020-07-04 11:18:13');


